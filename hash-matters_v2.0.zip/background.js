// Add the context menu option for hashing a manually downloaded file
browser.menus.create({
  id: "hash-manual-file",
  title: "Select File for Hashing (SHA256)",
  contexts: ["all"]
});

// Function to manually select a file and calculate SHA256
async function hashSelectedFile() {
  console.log("Prompting user to select a file for hashing...");

  // Use a hidden file input to allow user to select the file
  let inputElement = document.createElement("input");
  inputElement.type = "file";
  inputElement.onchange = async (event) => {
    let file = event.target.files[0];
    if (file) {
      console.log("File selected:", file.name);

      // Read the file as an array buffer
      let arrayBuffer = await file.arrayBuffer();
      console.log("File loaded, calculating SHA256...");

      // Calculate SHA256 hash
      let hash = await calculateSHA256(arrayBuffer);
      console.log("SHA256 Hash:", hash);

      // Save the hash to ioc.txt
      saveHashToTextFile(`${file.name}: ${hash}`);
    } else {
      console.error("No file selected.");
    }
  };
  inputElement.click();
}

// Function to calculate SHA256 hash
async function calculateSHA256(buffer) {
  const hashBuffer = await crypto.subtle.digest("SHA-256", buffer);
  return Array.from(new Uint8Array(hashBuffer))
    .map(b => b.toString(16).padStart(2, '0'))
    .join('');
}

// Function to save the hash to ioc.txt
function saveHashToTextFile(hash) {
  console.log("Saving hash to ioc.txt...");

  const blob = new Blob([hash + "\n"], { type: "text/plain" });
  const url = URL.createObjectURL(blob);
  
  // Download the ioc.txt file with the hash
  browser.downloads.download({
    url: url,
    filename: "ioc.txt",
    saveAs: true  // Prompt user for location to save the file
  });
}

// Add event listener for context menu click
browser.menus.onClicked.addListener(async (info, tab) => {
  if (info.menuItemId === "hash-manual-file") {
    await hashSelectedFile();
  }
});
