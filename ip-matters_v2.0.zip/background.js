browser.menus.create({
  id: "extract-ips",
  title: "Extract IPs ",
  contexts: ["message_list"]
});

async function extractIPs(messageIds) {
  let ipList = [];
  for (let messageId of messageIds) {
    let message = await browser.messages.getFull(messageId);
    let headers = message.headers["received"];
    for (let header of headers) {
      let ipMatch = header.match(/\b\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}\b/);
      if (ipMatch) {
        ipList.push(ipMatch[0]);
      }
    }
  }
  return ipList;
}

function downloadBlacklist(ipList) {
  const blob = new Blob([ipList.join("\n")], { type: "text/plain" });
  const url = URL.createObjectURL(blob);
  browser.downloads.download({
    url: url,
    filename: "ip-blacklist.txt",
    saveAs: true
  });
}

browser.menus.onClicked.addListener(async (info, tab) => {
  if (info.menuItemId === "extract-ips") {
    let messageIds = info.selectedMessages.messages.map(msg => msg.id);
    let ipList = await extractIPs(messageIds);
    downloadBlacklist(ipList);
  }
});
